---------------------
PenTBox 1.4 Readme EN
---------------------

PenTBox is a Security Suite that packs security and stability testing oriented tools
for networks and systems.

All of these tools are for security testing purpose, is a helping program for IT Administrators to test and
improve security and stability of networks and applications. In addition, can be used by ordinary users
to do simple operations.

Programmed in Ruby and oriented to GNU/Linux systems, but compatible with Windows, MacOS and every systems
where Ruby works.

It is free, licensed under GNU/GPLv3.
If you want to report errors, give feedback and new code or ideas, contact.


Technical information and features.
-----------------------------------

Languaje: Ruby (http://www.ruby-lang.org/)

O.Systems: Your system supports Ruby? Then, your system is perfect. GNU/Linux, Unix-like, MacOS, Windows ...

Suite tools:

- Cryptography tools
	Base64 Encoder & Decoder
	Multi-Digest (MD5, SHA1, SHA256, SHA384, SHA512, RIPEMD-160)
	Hash Password Cracker (MD5, SHA1, SHA256, SHA384, SHA512, RIPEMD-160)
	Secure Password Generator
- Network tools
	Net DoS Tester
	TCP port scanner
	Honeypot
	Fuzzer
	DNS and host gathering
- Extra
	L33t Sp3@k Converter


How to run the program.
-----------------------

- GNU/Linux and MacOS:

You only need to have installed Ruby to run the program. You can download it from
http://www.ruby-lang.org/en/downloads/ or in the repositories of your GNU/Linux distribution.

In Debian or Debian-based systems (like Ubuntu) you can install Ruby typing this in your Terminal:
apt-get install ruby
or
sudo apt-get install ruby

In new versions of MacOS, Ruby should be installed by default.

After installation, open a Terminal and run the program:
ruby pentbox.rb
or
ruby '/home/myname/Desktop/pentbox.rb'
or
./pentbox.rb

- Windows:

In Windows edition, Ruby is included in the archive. Decompress all and run loader.bat.
This installs Ruby (if it isn't installed) and runs the program.

Configuration.
--------------

In the principal file (pentbox.rb) you have some configuration lines with information.
Check this if you have problems or you want to change something.

Follow the project on http://pentbox.net/ or http://sourceforge.net/projects/pentbox/

See you!
